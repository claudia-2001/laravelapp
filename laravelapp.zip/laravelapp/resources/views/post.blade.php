<!DOCTYPE html>
<html lang="es">

<head>

    <title> Mi blog </title>
    <link rel="stylesheet" href="/app.css">

</head>

<body>

    <article>

    <?= $post; ?>

    </article>

    <a href="/"> Volver atrÃ¡s </a>

</body>

</html>
