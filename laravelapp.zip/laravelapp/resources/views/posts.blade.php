<!DOCTYPE html>
<html lang="es">

<head>

    <title> Mi blog </title>
    <link rel="stylesheet" href="/app.css">
    <!-- <script src="app.js"></script> -->

</head>

<body>

    <?php foreach ($posts as $post) : ?>

        <article>
            <?= $post; ?>
        </article>

    <?php endforeach; ?>

</body>

</html>
