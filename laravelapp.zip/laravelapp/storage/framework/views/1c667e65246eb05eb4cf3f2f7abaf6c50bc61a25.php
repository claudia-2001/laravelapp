<!DOCTYPE html>


<title>laravelapp</title>
<link rel="stylesheet" href="/app.css">
<script src="/app.js"></script>

<body>
    <h1>Hello World</h1>
</body>
<?php /**PATH C:\Users\USUARIO\Desktop\laragon\www\laravelapp\resources\views/welcome.blade.php ENDPATH**/ ?>