<!DOCTYPE html>


<title>laravelapp</title>
<link rel="stylesheet" href="/app.css">


<body>
<article>
    <?= $post; ?>
</article>


    <a href="/">Go Back</a>
</body>

<?php /**PATH C:\Users\USUARIO\Desktop\laragon\www\laravelapp\resources\views/post.blade.php ENDPATH**/ ?>