<!DOCTYPE html>


<title>laravelapp</title>
<link rel="stylesheet" href="/app.css">


<body>
    <article>
        <h1><a href="/post">My first post</a></h1>

        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum accusamus numquam molestias voluptate nesciunt at natus quasi iusto. Expedita at sed possimus enim est ipsum placeat ab dolores! Facere, voluptas!
        </p>
    </article>

    <article>
        <h1><a href="/post">My second post</a></h1>

        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum accusamus numquam molestias voluptate nesciunt at natus quasi iusto. Expedita at sed possimus enim est ipsum placeat ab dolores! Facere, voluptas!
        </p>
    </article>

    <article>
        <h1><a href="/post">My third post</a></h1>

        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum accusamus numquam molestias voluptate nesciunt at natus quasi iusto. Expedita at sed possimus enim est ipsum placeat ab dolores! Facere, voluptas!
        </p>
    </article>
</body>

<?php /**PATH C:\Users\USUARIO\Desktop\laragon\www\laravelapp\resources\views/posts.blade.php ENDPATH**/ ?>